RSS Feed Sample
===============

This example demonstrates the usage of the Spring Integration RSS Feed Module using a **Feed Inbound Channel Adapter**. In order to run the sample, execute the test case located in the **org.springframework.integration.samples.feed** package.

